import { Queue } from './queue';
import { ListElement, List } from './lists';

class Triage<T> {

    private black = new PriorityQueue<T>(0);
    private red = new PriorityQueue<T>(1);
    private yellow = new PriorityQueue<T>(2);
    private green = new PriorityQueue<T>(3);

    private messages = {
        black: 'is expectant, give him/her painkillers',
        red: 'is in emergency',
        yellow: 'is in warning',
        green: 'is derived to second triage'
    }

    add(item: T, color: string, copies?: number): PriorityQueue<T> {
        if(copies) {
            for(let i = 0; i < copies; i++) {
                this[color].add(item);
            }
        } else {
            this[color].add(item);
        }
        return this[color];
    };

    extract(): ListElement<T> {

        if(this.red.scout()) {
            return this._extractFromPriorityQueue('red');
        }

        if(this.yellow.scout()) {
            return this._extractFromPriorityQueue('yellow');
        }

        if(this.green.scout()) {
            return this._extractFromPriorityQueue('green');
        }

        if(this.black.scout()) {
            return this._extractFromPriorityQueue('black');
        }

        return null
    }

    private _extractFromPriorityQueue(color: string): ListElement<T> {
        const extracted: ListElement<T> = this[color].extract();
        console.log(`${extracted.value} ${this.messages[color]}`);
        return extracted
    }

    roundRobinAssistance(maximumCycles?: number): void {
        const MAXIMUM_CYCLES = maximumCycles || 4;

        let currentCycle = {
            iteration: 0,
            color: 'red'
        };

        let colorCycle = {
            red: 'yellow',
            yellow: 'green',
            green: 'black',
            black: 'red'
        }

        let colorDone = {
            red: false,
            yellow: false,
            green: false,
            black: false
        }

        let patientsLeft = true;

        while(patientsLeft) {
            if(currentCycle.iteration < MAXIMUM_CYCLES) {
                if(this[currentCycle.color].scout()) {
                    this._extractFromPriorityQueue(currentCycle.color);
                    currentCycle.iteration++;
                } else {
                    currentCycle.iteration = 0;
                    currentCycle.color = colorCycle[currentCycle.color];
                    colorDone[currentCycle.color] = true;
                }
            } else {
                currentCycle.iteration = 0;
                currentCycle.color = colorCycle[currentCycle.color];
            }

            if(colorDone.red && colorDone.yellow && colorDone.green && colorDone.black) {
                patientsLeft = false;
            }
        }
        
        console.log('Job done');
    }

    assistPatients(): void {
        let patientsLeft = true;
        while(patientsLeft) {
            patientsLeft = !!this.extract();
        }

        console.log('Job done');
    }

}

class PriorityQueue<T> extends Queue<T> {

    public priorityValue: number;
    
    constructor(priorityValue: number) {
        super()
        this.priorityValue = priorityValue;
    }

}

const myTriage = new Triage<string>();

myTriage.add('John', 'black', 14);
myTriage.add('Doe', 'red', 20);
myTriage.add('Sam', 'green', 16);
myTriage.add('Smith', 'yellow', 28);
myTriage.roundRobinAssistance(3);

